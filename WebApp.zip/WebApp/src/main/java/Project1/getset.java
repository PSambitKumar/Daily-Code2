package Project1;

public class getset {
	int result1;
	int result2;
	public int getResult1() {
		return result1;
	}
	public void setResult1(int result1) {
		this.result1 = result1;
	}
	public int getResult2() {
		return result2;
	}
	public void setResult2(int result2) {
		this.result2 = result2;
	}
}
