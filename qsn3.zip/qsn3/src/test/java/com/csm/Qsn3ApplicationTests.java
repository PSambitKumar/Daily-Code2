package com.csm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qsn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
